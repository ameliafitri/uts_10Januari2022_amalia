<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('_partials/head.php'); ?>
</head>

<body>
	<?php $this->load->view('_partials/navbar.php'); ?>
	
	<h1>About Page</h1>

	<?php $this->load->view('_partials/footer.php'); ?>
</body>

</html>
